# Appointment Calendar

A Pen created on CodePen.io. Original URL: [https://codepen.io/guifelix/pen/LMjZpX](https://codepen.io/guifelix/pen/LMjZpX).

Made for hackerrank code evaluation