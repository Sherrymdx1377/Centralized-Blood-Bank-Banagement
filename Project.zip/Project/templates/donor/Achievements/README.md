# Pure CSS/SVG Donut Chart Animated With Percentage

A Pen created on CodePen.io. Original URL: [https://codepen.io/matttherat/pen/EeMaEw](https://codepen.io/matttherat/pen/EeMaEw).

